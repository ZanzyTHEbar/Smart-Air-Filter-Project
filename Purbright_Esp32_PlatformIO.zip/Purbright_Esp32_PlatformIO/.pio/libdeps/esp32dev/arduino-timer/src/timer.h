#warning "Including this file is deprecated. Please #include <arduino-timer.h> instead."

#include <arduino-timer.h>
